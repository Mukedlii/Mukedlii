# SkillBridge Deployment Guide

## Replit Deploy (Javasolt módszer)

SkillBridge-et a legegyszerűbben Replit Deploy-jal lehet interneten publikálni:

### 1. Replit Deploy beállítása
1. A Replit projektben kattints a **"Deploy"** gombra a bal oldali menüben
2. Válaszd ki a **"Autoscale"** deployment típust
3. Add meg a következő environment változókat:
   - `DATABASE_URL` - PostgreSQL adatbázis URL
   - `STRIPE_SECRET_KEY` - Stripe titkos kulcs
   - `VITE_STRIPE_PUBLIC_KEY` - Stripe nyilvános kulcs

### 2. Custom domain beállítása (opcionális)
- A Replit Deploy automatikusan biztosít egy `.replit.app` domain-t
- Egyedi domain hozzáadásához:
  1. Menj a Deploy beállításokhoz
  2. Add hozzá a custom domain-t
  3. Frissítsd a DNS beállításokat a domain szolgáltatónál

### 3. SSL és biztonság
- Replit automatikusan biztosítja az SSL tanúsítványt
- HTTPS kapcsolat minden deploy-nál

---

## Alternatív deployment módszerek

### Vercel
1. GitHub repository létrehozása
2. Vercel account és projekt létrehozása
3. Environment változók beállítása
4. Automatikus deployment GitHub push-kor

### Netlify
1. Build command: `npm run build`
2. Publish directory: `dist`
3. Environment változók beállítása

### Railway
1. GitHub repository kapcsolása
2. PostgreSQL addon hozzáadása
3. Environment változók konfigurálása

### DigitalOcean App Platform
1. GitHub repository
2. Node.js alkalmazás típus
3. Database service hozzáadása

---

## Szükséges environment változók

```
DATABASE_URL=postgresql://user:password@host:port/database
STRIPE_SECRET_KEY=sk_live_...
VITE_STRIPE_PUBLIC_KEY=pk_live_...
```

## Fontos megjegyzések

1. **Adatbázis**: Production környezetben külön PostgreSQL adatbázis szükséges
2. **Stripe kulcsok**: Development helyett live kulcsokat használj
3. **Domain**: HTTPS kötelező Stripe fizetésekhez
4. **Teljesítmény**: Autoscale deployment ajánlott nagyobb forgalomhoz

## Költségek

- **Replit Deploy**: Ingyenes kezdő tier, majd usage-based pricing
- **Vercel**: Ingyenes hobby tier, pro tier $20/hó
- **Netlify**: Ingyenes tier, pro tier $19/hó
- **Railway**: Usage-based, $5/hó kezdőcsomag

## Következő lépések deployment után

1. SSL tanúsítvány ellenőrzése
2. Domain DNS beállítások
3. Stripe webhook endpoints beállítása
4. Google Analytics vagy monitoring hozzáadása
5. CDN konfiguráció (opcionális)