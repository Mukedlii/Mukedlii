import { 
  users, categories, services, orders, reviews, messages,
  type User, type InsertUser, 
  type Category, type InsertCategory,
  type Service, type InsertService,
  type Order, type InsertOrder,
  type Review, type InsertReview,
  type Message, type InsertMessage,
  type ServiceWithProvider, type OrderWithDetails
} from "@shared/schema";
import { db } from "./db";
import { eq, and, like, desc } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;

  // Categories
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;

  // Services
  getServices(filters?: { categoryId?: number; searchTerm?: string }): Promise<ServiceWithProvider[]>;
  getService(id: number): Promise<ServiceWithProvider | undefined>;
  getServicesByProvider(providerId: number): Promise<ServiceWithProvider[]>;
  createService(service: InsertService): Promise<Service>;
  updateService(id: number, updates: Partial<Service>): Promise<Service>;

  // Orders
  getOrders(userId: number): Promise<OrderWithDetails[]>;
  getOrder(id: number): Promise<OrderWithDetails | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: number, updates: Partial<Order>): Promise<Order>;

  // Reviews
  getReviewsForService(serviceId: number): Promise<ReviewWithUser[]>;
  createReview(review: InsertReview): Promise<Review>;
  markReviewHelpful(reviewId: number): Promise<void>;
  getServiceRatingStats(serviceId: number): Promise<{ averageRating: number; totalReviews: number }>;

  // Messages
  getMessages(orderId: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    this.seedData();
  }

  private async seedData() {
    try {
      // Check if categories already exist
      const existingCategories = await db.select().from(categories).limit(1);
      if (existingCategories.length > 0) return; // Already seeded

      // Seed categories
      const seedCategories = [
        { name: "AI Content Creation", description: "High-ROI AI-powered content services that drive immediate traffic and sales" },
        { name: "Marketing Campaigns", description: "Proven marketing strategies that generate leads and revenue within 48 hours" },
        { name: "Design & Branding", description: "Professional design services that boost conversions and brand value" },
        { name: "Tech Setup", description: "Fast technical implementations that increase efficiency and profits" },
        { name: "Business Automation", description: "Automated systems that save time and generate passive income" }
      ];

      const insertedCategories = await db.insert(categories).values(seedCategories).returning();

      // Seed users
      const seedUsers = [
        {
          username: "aiexpert_sarah",
          email: "sarah@aiexpert.com",
          fullName: "Sarah Mitchell",
          password: "password123",
          isProvider: true,
          profileImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
          bio: "AI content strategist with 5+ years experience. Generated $2M+ in revenue for clients through AI-powered content marketing.",
          rating: 4.9,
          reviewCount: 127
        },
        {
          username: "marketing_guru",
          email: "alex@marketingguru.com", 
          fullName: "Alex Chen",
          password: "password123",
          isProvider: true,
          profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
          bio: "Performance marketer specializing in high-ROI campaigns. Average client sees 300% ROAS within 30 days.",
          rating: 4.8,
          reviewCount: 89
        },
        {
          username: "design_master",
          email: "emma@designmaster.com",
          fullName: "Emma Rodriguez", 
          password: "password123",
          isProvider: true,
          profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
          bio: "Brand designer who increased client conversions by 45% on average through strategic design.",
          rating: 4.9,
          reviewCount: 156
        }
      ];

      const insertedUsers = await db.insert(users).values(seedUsers).returning();

      // Seed services
      const seedServices = [
        {
          providerId: insertedUsers[0].id,
          categoryId: insertedCategories[0].id,
          title: "I will create 50 high-converting AI blog posts that drive traffic and sales",
          description: "Get 50 professionally written, SEO-optimized blog posts that actually convert visitors into customers. Each post is researched, engaging, and designed to rank on Google while driving sales. Includes keyword research, meta descriptions, and call-to-action optimization.",
          price: 19900,
          deliveryTime: 48,
          image: "https://images.unsplash.com/photo-1552664730-d307ca884978?w=500&h=300&fit=crop",
          features: [
            "50 unique, high-quality blog posts (800-1200 words each)",
            "Full SEO optimization with target keywords",
            "Conversion-focused writing that drives sales",
            "Meta descriptions and title tags included",
            "Ready-to-publish WordPress format",
            "30-day revision guarantee"
          ],
          tags: ["AI Content", "SEO", "Blog Writing", "Content Marketing", "Traffic Generation"]
        },
        {
          providerId: insertedUsers[1].id,
          categoryId: insertedCategories[1].id,
          title: "I will setup a complete Facebook ad campaign that generates leads in 24 hours",
          description: "Launch a profitable Facebook advertising campaign that starts generating qualified leads within 24 hours. Includes audience research, ad creative, landing page optimization, and campaign monitoring. Average client sees 4x ROAS.",
          price: 9900,
          deliveryTime: 24,
          image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=500&h=300&fit=crop",
          features: [
            "Complete campaign setup and launch",
            "Targeted audience research and segmentation", 
            "3 high-converting ad creatives",
            "Landing page optimization review",
            "24-hour campaign monitoring",
            "Performance report and recommendations"
          ],
          tags: ["Facebook Ads", "Lead Generation", "PPC", "Digital Marketing", "ROI Optimization"]
        },
        {
          providerId: insertedUsers[2].id,
          categoryId: insertedCategories[2].id,
          title: "I will design a conversion-optimized landing page that increases sales by 40%",
          description: "Get a professionally designed landing page that converts visitors into customers. Based on proven psychological principles and A/B tested elements. Includes mobile optimization, fast loading, and conversion tracking setup.",
          price: 14900,
          deliveryTime: 48,
          image: "https://images.unsplash.com/photo-1561070791-2526d30994b5?w=500&h=300&fit=crop",
          features: [
            "Custom landing page design (desktop + mobile)",
            "Conversion optimization based on psychology",
            "A/B tested elements and layouts",
            "Fast loading optimization (under 3 seconds)",
            "Integration with analytics and tracking",
            "2 rounds of revisions included"
          ],
          tags: ["Landing Page", "Conversion Optimization", "Web Design", "UX/UI", "Sales Funnel"]
        }
      ];

      await db.insert(services).values(seedServices);
    } catch (error) {
      console.log("Database seeding failed or already completed:", error);
    }
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values({ ...insertUser, rating: 0, reviewCount: 0 })
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    if (!user) {
      throw new Error("User not found");
    }
    return user;
  }

  async updateUserSubscription(userId: number, subscriptionData: {
    isPremium: boolean;
    premiumPlan?: string;
    premiumExpiresAt?: Date;
    stripeSubscriptionId?: string;
  }): Promise<User> {
    return this.updateUser(userId, subscriptionData);
  }

  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }

  async getServices(filters?: { categoryId?: number; searchTerm?: string }): Promise<ServiceWithProvider[]> {
    let query = db
      .select({
        id: services.id,
        providerId: services.providerId,
        categoryId: services.categoryId,
        title: services.title,
        description: services.description,
        price: services.price,
        deliveryTime: services.deliveryTime,
        image: services.image,
        features: services.features,
        tags: services.tags,
        createdAt: services.createdAt,
        provider: {
          id: users.id,
          username: users.username,
          fullName: users.fullName,
          profileImage: users.profileImage,
          rating: users.rating,
          reviewCount: users.reviewCount
        },
        category: {
          name: categories.name
        }
      })
      .from(services)
      .innerJoin(users, eq(services.providerId, users.id))
      .innerJoin(categories, eq(services.categoryId, categories.id));

    if (filters?.categoryId) {
      query = query.where(eq(services.categoryId, filters.categoryId)) as any;
    }

    if (filters?.searchTerm) {
      query = query.where(like(services.title, `%${filters.searchTerm}%`)) as any;
    }

    return await query as any;
  }

  async getService(id: number): Promise<ServiceWithProvider | undefined> {
    const [service] = await db
      .select({
        id: services.id,
        providerId: services.providerId,
        categoryId: services.categoryId,
        title: services.title,
        description: services.description,
        price: services.price,
        deliveryTime: services.deliveryTime,
        image: services.image,
        features: services.features,
        tags: services.tags,
        createdAt: services.createdAt,
        provider: {
          id: users.id,
          username: users.username,
          fullName: users.fullName,
          profileImage: users.profileImage,
          rating: users.rating,
          reviewCount: users.reviewCount
        },
        category: {
          name: categories.name
        }
      })
      .from(services)
      .innerJoin(users, eq(services.providerId, users.id))
      .innerJoin(categories, eq(services.categoryId, categories.id))
      .where(eq(services.id, id));

    return service as any || undefined;
  }

  async getServicesByProvider(providerId: number): Promise<ServiceWithProvider[]> {
    return await db
      .select({
        id: services.id,
        providerId: services.providerId,
        categoryId: services.categoryId,
        title: services.title,
        description: services.description,
        price: services.price,
        deliveryTime: services.deliveryTime,
        image: services.image,
        features: services.features,
        tags: services.tags,
        createdAt: services.createdAt,
        provider: {
          id: users.id,
          username: users.username,
          fullName: users.fullName,
          profileImage: users.profileImage,
          rating: users.rating,
          reviewCount: users.reviewCount
        },
        category: {
          name: categories.name
        }
      })
      .from(services)
      .innerJoin(users, eq(services.providerId, users.id))
      .innerJoin(categories, eq(services.categoryId, categories.id))
      .where(eq(services.providerId, providerId)) as any;
  }

  async createService(insertService: InsertService): Promise<Service> {
    const [service] = await db
      .insert(services)
      .values(insertService)
      .returning();
    return service;
  }

  async updateService(id: number, updates: Partial<Service>): Promise<Service> {
    const [service] = await db
      .update(services)
      .set(updates)
      .where(eq(services.id, id))
      .returning();
    if (!service) {
      throw new Error("Service not found");
    }
    return service;
  }

  async getOrders(userId: number): Promise<OrderWithDetails[]> {
    return await db
      .select({
        id: orders.id,
        clientId: orders.clientId,
        providerId: orders.providerId,
        serviceId: orders.serviceId,
        status: orders.status,
        totalAmount: orders.totalAmount,
        requirements: orders.requirements,
        createdAt: orders.createdAt,
        service: {
          title: services.title,
          image: services.image
        },
        client: {
          username: users.username,
          fullName: users.fullName
        },
        provider: {
          username: users.username,
          fullName: users.fullName
        }
      })
      .from(orders)
      .innerJoin(services, eq(orders.serviceId, services.id))
      .innerJoin(users, eq(orders.clientId, users.id))
      .where(eq(orders.clientId, userId)) as any;
  }

  async getOrder(id: number): Promise<OrderWithDetails | undefined> {
    const [order] = await db
      .select({
        id: orders.id,
        clientId: orders.clientId,
        providerId: orders.providerId,
        serviceId: orders.serviceId,
        status: orders.status,
        totalAmount: orders.totalAmount,
        requirements: orders.requirements,
        createdAt: orders.createdAt,
        service: {
          title: services.title,
          image: services.image
        },
        client: {
          username: users.username,
          fullName: users.fullName
        },
        provider: {
          username: users.username,
          fullName: users.fullName
        }
      })
      .from(orders)
      .innerJoin(services, eq(orders.serviceId, services.id))
      .innerJoin(users, eq(orders.clientId, users.id))
      .where(eq(orders.id, id)) as any;

    return order || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async updateOrder(id: number, updates: Partial<Order>): Promise<Order> {
    const [order] = await db
      .update(orders)
      .set(updates)
      .where(eq(orders.id, id))
      .returning();
    if (!order) {
      throw new Error("Order not found");
    }
    return order;
  }

  async getReviewsForService(serviceId: number): Promise<Review[]> {
    return await db.select().from(reviews).where(eq(reviews.orderId, serviceId));
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values(insertReview)
      .returning();
    return review;
  }

  async getMessages(orderId: number): Promise<Message[]> {
    return await db.select().from(messages).where(eq(messages.orderId, orderId));
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }
}

export const storage = new DatabaseStorage();