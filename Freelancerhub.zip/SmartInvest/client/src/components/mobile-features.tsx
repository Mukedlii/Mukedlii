import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Smartphone, Wifi, Bell, Download, CheckCircle } from 'lucide-react';
import { usePWA } from '@/hooks/use-pwa';

export function MobileAppFeatures() {
  const { isInstalled } = usePWA();
  
  const features = [
    {
      icon: Smartphone,
      title: 'Native App Experience',
      description: 'Full-screen app interface without browser UI',
      available: true,
    },
    {
      icon: Wifi,
      title: 'Offline Support',
      description: 'Browse services and manage orders without internet',
      available: true,
    },
    {
      icon: Bell,
      title: 'Push Notifications',
      description: 'Get notified about new orders and messages',
      available: false, // Would require backend implementation
    },
    {
      icon: Download,
      title: 'Install to Home Screen',
      description: 'Add SkillBridge to your device home screen',
      available: !isInstalled,
    },
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {features.map(({ icon: Icon, title, description, available }) => (
        <Card key={title} className={!available ? 'opacity-60' : ''}>
          <CardHeader className="pb-3">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <Icon className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1">
                <CardTitle className="text-sm">{title}</CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <CardDescription className="text-xs">{description}</CardDescription>
                  {available && <Badge variant="secondary" className="text-xs">Available</Badge>}
                  {!available && <Badge variant="outline" className="text-xs">Coming Soon</Badge>}
                </div>
              </div>
              {available && <CheckCircle className="w-4 h-4 text-green-500" />}
            </div>
          </CardHeader>
        </Card>
      ))}
    </div>
  );
}

export function MobileOptimizedLayout({ children }: { children: React.ReactNode }) {
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if running as standalone PWA
    setIsStandalone(window.matchMedia('(display-mode: standalone)').matches);
  }, []);

  return (
    <div className={`${isStandalone ? 'standalone-app' : ''} mobile-optimized`}>
      {children}
    </div>
  );
}