import { useState } from "react";
import { useLocation } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";

interface SearchBarProps {
  placeholder?: string;
  size?: "sm" | "lg";
  className?: string;
}

export default function SearchBar({ placeholder = "What service are you looking for?", size = "lg", className = "" }: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [, navigate] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/services?search=${encodeURIComponent(searchTerm)}`);
    }
  };

  const inputSize = size === "lg" ? "w-full pl-6 pr-20 py-4 text-lg" : "w-full pl-10 pr-4 py-2";
  const buttonSize = size === "lg" ? "absolute right-2 top-2 px-6 py-2" : "absolute right-2 top-1/2 transform -translate-y-1/2 px-4 py-1";

  return (
    <form onSubmit={handleSearch} className={`relative ${className}`}>
      <Input
        type="text"
        placeholder={placeholder}
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className={`${inputSize} rounded-lg text-gray-900 focus:ring-2 focus:ring-accent border-0`}
      />
      <Button
        type="submit"
        className={`${buttonSize} bg-accent text-white rounded-md hover:bg-yellow-600 font-semibold`}
      >
        {size === "lg" ? "Search" : <Search className="w-4 h-4" />}
      </Button>
    </form>
  );
}
