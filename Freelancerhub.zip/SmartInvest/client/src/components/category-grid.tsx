import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card } from "@/components/ui/card";
import { Category } from "@shared/schema";

export default function CategoryGrid() {
  const [, navigate] = useLocation();
  
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  if (isLoading) {
    return <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {Array.from({ length: 4 }, (_, i) => (
        <div key={i} className="animate-pulse">
          <Card className="bg-gray-200 rounded-lg p-6 h-32"></Card>
        </div>
      ))}
    </div>;
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {categories?.map((category) => (
        <Card
          key={category.id}
          className="category-card bg-gray-50 rounded-lg p-6 hover:shadow-md transition-shadow cursor-pointer group"
          onClick={() => navigate(`/services?category=${category.id}`)}
        >
          <div className="text-3xl mb-4 group-hover:scale-110 transition-transform">
            <i className={`${category.icon} text-primary`}></i>
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
          <p className="text-gray-600 text-sm">{category.description}</p>
        </Card>
      ))}
    </div>
  );
}
