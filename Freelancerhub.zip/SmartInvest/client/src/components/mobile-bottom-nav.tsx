import { Link, useLocation } from 'wouter';
import { Home, Search, Plus, User, MessageCircle } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { cn } from '@/lib/utils';

export default function MobileBottomNav() {
  const [location] = useLocation();
  const { user } = useAuth();

  if (!user) return null;

  const navItems = [
    { icon: Home, label: 'Home', href: '/', key: 'home' },
    { icon: Search, label: 'Browse', href: '/services', key: 'browse' },
    { icon: Plus, label: 'Create', href: '/create-service', key: 'create' },
    { icon: MessageCircle, label: 'Orders', href: '/dashboard', key: 'orders' },
    { icon: User, label: 'Profile', href: '/dashboard?tab=profile', key: 'profile' },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 safe-area-bottom z-50">
      <div className="flex justify-around items-center py-2">
        {navItems.map(({ icon: Icon, label, href, key }) => (
          <Link key={key} href={href}>
            <div className={cn(
              "flex flex-col items-center py-2 px-3 rounded-lg transition-colors min-h-[44px] min-w-[44px]",
              location === href || 
              (key === 'profile' && location.includes('dashboard') && location.includes('tab=profile')) ||
              (key === 'orders' && location === '/dashboard' && !location.includes('tab='))
                ? "text-primary bg-primary/10" 
                : "text-gray-600 hover:text-primary"
            )}>
              <Icon className="w-5 h-5" />
              <span className="text-xs mt-1 font-medium">{label}</span>
            </div>
          </Link>
        ))}
      </div>
    </nav>
  );
}