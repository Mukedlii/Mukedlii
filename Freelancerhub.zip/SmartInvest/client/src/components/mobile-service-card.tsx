import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Clock, CheckCircle } from "lucide-react";
import { ServiceWithProvider } from "@shared/schema";
import RatingDisplay from "./rating-display";

interface MobileServiceCardProps {
  service: ServiceWithProvider;
  layout?: 'grid' | 'list';
}

export default function MobileServiceCard({ service, layout = 'grid' }: MobileServiceCardProps) {
  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(0)}`;
  };

  if (layout === 'list') {
    return (
      <Link href={`/services/${service.id}`}>
        <Card className="mobile-card hover:shadow-md transition-shadow">
          <CardContent className="p-4">
            <div className="flex space-x-4">
              {/* Service Image */}
              <div className="flex-shrink-0">
                <img
                  src={service.image || "/placeholder-service.jpg"}
                  alt={service.title}
                  className="w-20 h-20 object-cover rounded-lg"
                />
              </div>
              
              {/* Service Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 text-sm line-clamp-2 leading-tight">
                    {service.title}
                  </h3>
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {service.category.name}
                  </Badge>
                </div>
                
                {/* Provider Info */}
                <div className="flex items-center mb-2">
                  <Avatar className="w-6 h-6 mr-2">
                    <AvatarImage src={service.provider.profileImage} />
                    <AvatarFallback className="text-xs">
                      {service.provider.fullName?.charAt(0) || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-gray-600 truncate">
                    {service.provider.fullName}
                  </span>
                </div>
                
                {/* Rating and Price */}
                <div className="flex items-center justify-between">
                  <RatingDisplay 
                    rating={service.provider.rating || 0}
                    reviewCount={service.provider.reviewCount || 0}
                    size="sm"
                  />
                  <div className="text-right">
                    <div className="text-lg font-bold text-primary">
                      {formatPrice(service.price)}
                    </div>
                    <div className="text-xs text-gray-500">
                      {service.deliveryTime}d delivery
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    );
  }

  return (
    <Link href={`/services/${service.id}`}>
      <Card className="mobile-card hover:shadow-md transition-shadow h-full">
        <CardContent className="p-0">
          {/* Service Image */}
          <div className="relative">
            <img
              src={service.image || "/placeholder-service.jpg"}
              alt={service.title}
              className="w-full h-32 object-cover rounded-t-lg"
            />
            <Badge 
              variant="secondary" 
              className="absolute top-2 left-2 text-xs bg-white/90"
            >
              {service.category.name}
            </Badge>
          </div>
          
          <div className="p-3">
            {/* Provider Info */}
            <div className="flex items-center mb-2">
              <Avatar className="w-6 h-6 mr-2">
                <AvatarImage src={service.provider.profileImage} />
                <AvatarFallback className="text-xs">
                  {service.provider.fullName?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              <span className="text-xs text-gray-600 truncate">
                {service.provider.fullName}
              </span>
              {service.provider.rating >= 4.5 && (
                <CheckCircle className="w-3 h-3 text-green-500 ml-1 flex-shrink-0" />
              )}
            </div>
            
            {/* Service Title */}
            <h3 className="font-semibold text-sm text-gray-900 mb-2 line-clamp-2 leading-tight">
              {service.title}
            </h3>
            
            {/* Rating */}
            <div className="mb-3">
              <RatingDisplay 
                rating={service.provider.rating || 0}
                reviewCount={service.provider.reviewCount || 0}
                size="sm"
              />
            </div>
            
            {/* Price and Delivery */}
            <div className="flex items-center justify-between">
              <div className="flex items-center text-xs text-gray-500">
                <Clock className="w-3 h-3 mr-1" />
                {service.deliveryTime}d
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-500">Starting at</div>
                <div className="font-bold text-primary">
                  {formatPrice(service.price)}
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}