import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ThumbsUp, CheckCircle } from 'lucide-react';
import RatingDisplay from './rating-display';
import { Review } from '@shared/schema';

interface ReviewWithUser extends Review {
  client: {
    id: number;
    username: string;
    fullName: string;
    profileImage?: string;
  };
}

interface ReviewCardProps {
  review: ReviewWithUser;
  onHelpful?: (reviewId: number) => void;
  isHelpfulLoading?: boolean;
}

export default function ReviewCard({ review, onHelpful, isHelpfulLoading }: ReviewCardProps) {
  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(new Date(date));
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src={review.client.profileImage} />
              <AvatarFallback>
                {review.client.fullName?.charAt(0) || review.client.username?.charAt(0) || 'U'}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-medium">{review.client.fullName || review.client.username}</h4>
                {review.isRecommended && (
                  <Badge variant="secondary" className="text-xs">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Recommended
                  </Badge>
                )}
              </div>
              <p className="text-sm text-gray-500">{formatDate(review.createdAt)}</p>
            </div>
          </div>
          <RatingDisplay rating={review.rating} size="sm" showNumber={false} />
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        {review.comment && (
          <p className="text-gray-700 mb-4 leading-relaxed">{review.comment}</p>
        )}
        
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onHelpful?.(review.id)}
            disabled={isHelpfulLoading}
            className="text-gray-500 hover:text-primary"
          >
            <ThumbsUp className="w-4 h-4 mr-1" />
            Helpful ({review.helpfulCount || 0})
          </Button>
          
          <div className="flex items-center gap-1">
            <RatingDisplay rating={review.rating} size="sm" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}