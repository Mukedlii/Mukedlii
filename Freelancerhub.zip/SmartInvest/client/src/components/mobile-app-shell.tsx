import { ReactNode, useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/lib/auth';
import MobileBottomNav from './mobile-bottom-nav';
import Header from './header';
import MobileStatusBar from './mobile-status-bar';

interface MobileAppShellProps {
  children: ReactNode;
}

export default function MobileAppShell({ children }: MobileAppShellProps) {
  const [location] = useLocation();
  const { user } = useAuth();
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if app is running as standalone PWA
    const isStandaloneMode = window.matchMedia('(display-mode: standalone)').matches 
      || (window.navigator as any).standalone 
      || document.referrer.includes('android-app://');
    
    setIsStandalone(isStandaloneMode);

    // Add PWA-specific classes to body
    if (isStandaloneMode) {
      document.body.classList.add('pwa-standalone');
    }

    // Handle status bar on iOS
    if ((window.navigator as any).standalone) {
      document.documentElement.style.setProperty('--safe-area-inset-top', 'env(safe-area-inset-top)');
      document.documentElement.style.setProperty('--safe-area-inset-bottom', 'env(safe-area-inset-bottom)');
    }
  }, []);

  // Hide bottom nav on certain pages
  const hideBottomNav = ['/auth', '/checkout'].some(path => location.startsWith(path));
  
  // Hide header on mobile for certain pages to maximize space
  const hideHeaderOnMobile = ['/auth'].includes(location);

  return (
    <div className={`min-h-screen bg-gray-50 ${isStandalone ? 'pwa-app' : ''}`}>
      {/* Mobile Status Bar for PWA */}
      <MobileStatusBar />
      
      {/* Header - responsive for mobile */}
      {!(hideHeaderOnMobile) && <Header />}
      
      {/* Main content with proper spacing */}
      <main className={`
        ${isStandalone ? 'pwa-main' : ''}
        ${hideBottomNav ? '' : 'pb-20 md:pb-0'}
        ${hideHeaderOnMobile ? 'pt-0' : ''}
      `}>
        {children}
      </main>
      
      {/* Bottom navigation for mobile */}
      {!hideBottomNav && <MobileBottomNav />}
      
      {/* Safe area bottom for iOS home indicator */}
      {isStandalone && (
        <div 
          className="bg-white md:hidden" 
          style={{ 
            height: 'env(safe-area-inset-bottom)',
            minHeight: '20px'
          }} 
        />
      )}
    </div>
  );
}