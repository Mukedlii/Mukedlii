import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from "lucide-react";
import { ServiceWithProvider } from "@shared/schema";

interface ServiceCardProps {
  service: ServiceWithProvider;
}

export default function ServiceCard({ service }: ServiceCardProps) {
  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(0)}`;
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-3 h-3 ${
          i < rating ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  return (
    <Link href={`/services/${service.id}`}>
      <Card className="service-card bg-white rounded-lg shadow-sm hover:shadow-lg transition-shadow overflow-hidden cursor-pointer">
        <img
          src={service.image || "/placeholder-service.jpg"}
          alt={service.title}
          className="w-full h-48 object-cover"
        />
        
        <CardContent className="p-5">
          <div className="flex items-center mb-3">
            <Avatar className="w-10 h-10 mr-3">
              <AvatarImage src={service.provider.profileImage || ""} alt={service.provider.fullName} />
              <AvatarFallback>{service.provider.fullName?.charAt(0)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium text-gray-900">{service.provider.fullName}</p>
              <div className="flex items-center">
                <div className="flex mr-1">
                  {renderStars(service.provider.rating || 0)}
                </div>
                <span className="text-gray-600 text-sm">
                  {service.provider.rating?.toFixed(1)} ({service.provider.reviewCount})
                </span>
              </div>
            </div>
          </div>
          
          <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
            {service.title}
          </h3>
          
          <div className="flex justify-between items-center">
            <span className="text-gray-600 text-sm">Starting at</span>
            <span className="font-bold text-lg text-gray-900">
              {formatPrice(service.price)}
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
