import { Link } from "wouter";
import { BringToFront, Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center mb-4">
              <BringToFront className="text-primary text-2xl mr-2" />
              <span className="text-xl font-bold">FreelancerHub</span>
            </div>
            <p className="text-gray-400 mb-4">
              Connecting talent with opportunity. The trusted marketplace for professional services.
            </p>
            <div className="flex space-x-4">
              <Facebook className="text-gray-400 hover:text-white cursor-pointer" />
              <Twitter className="text-gray-400 hover:text-white cursor-pointer" />
              <Linkedin className="text-gray-400 hover:text-white cursor-pointer" />
              <Instagram className="text-gray-400 hover:text-white cursor-pointer" />
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link href="/services?category=1" className="text-gray-400 hover:text-white">Writing & Translation</Link></li>
              <li><Link href="/services?category=2" className="text-gray-400 hover:text-white">Design & Creative</Link></li>
              <li><Link href="/services?category=3" className="text-gray-400 hover:text-white">Tutoring & Teaching</Link></li>
              <li><Link href="/services?category=4" className="text-gray-400 hover:text-white">Business Consulting</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white">Help Center</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Trust & Safety</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Contact Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Community</a></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-400 hover:text-white">About Us</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Careers</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Press</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Terms of Service</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white">Privacy Policy</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 mt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400">© 2024 SkillBridge. All rights reserved.</p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <div className="w-4 h-4 bg-secondary rounded"></div>
              <span className="text-gray-400">Secure payments powered by Stripe</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
