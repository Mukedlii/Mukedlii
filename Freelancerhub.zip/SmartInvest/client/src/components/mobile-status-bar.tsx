import { useEffect, useState } from 'react';

export default function MobileStatusBar() {
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    const checkStandalone = () => {
      const isStandaloneMode = 
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone ||
        document.referrer.includes('android-app://');
      
      setIsStandalone(isStandaloneMode);
    };

    checkStandalone();
    window.addEventListener('resize', checkStandalone);
    
    return () => window.removeEventListener('resize', checkStandalone);
  }, []);

  if (!isStandalone) return null;

  return (
    <div 
      className="bg-primary w-full z-50"
      style={{ 
        height: 'env(safe-area-inset-top)',
        minHeight: '20px' // Fallback for devices without safe area
      }}
    />
  );
}