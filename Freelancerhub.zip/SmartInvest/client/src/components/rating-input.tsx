import { useState } from 'react';
import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RatingInputProps {
  value: number;
  onChange: (rating: number) => void;
  maxRating?: number;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  disabled?: boolean;
}

export default function RatingInput({ 
  value, 
  onChange, 
  maxRating = 5, 
  size = 'md',
  className,
  disabled = false
}: RatingInputProps) {
  const [hoverRating, setHoverRating] = useState(0);

  const sizes = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8'
  };

  const currentRating = hoverRating || value;

  return (
    <div className={cn("flex items-center gap-1", className)}>
      {Array.from({ length: maxRating }, (_, i) => (
        <button
          key={i}
          type="button"
          disabled={disabled}
          onMouseEnter={() => !disabled && setHoverRating(i + 1)}
          onMouseLeave={() => !disabled && setHoverRating(0)}
          onClick={() => !disabled && onChange(i + 1)}
          className={cn(
            "transition-colors hover:scale-110 transform duration-150",
            disabled && "cursor-not-allowed opacity-50"
          )}
        >
          <Star
            className={cn(
              sizes[size],
              i < currentRating
                ? "fill-yellow-400 text-yellow-400"
                : "fill-gray-200 text-gray-200 hover:fill-yellow-300 hover:text-yellow-300"
            )}
          />
        </button>
      ))}
      <span className="ml-2 text-sm text-gray-600">
        {currentRating > 0 ? `${currentRating} star${currentRating !== 1 ? 's' : ''}` : 'No rating'}
      </span>
    </div>
  );
}