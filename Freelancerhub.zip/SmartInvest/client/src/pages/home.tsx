import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import ServiceCard from "@/components/service-card";
import CategoryGrid from "@/components/category-grid";
import SearchBar from "@/components/search-bar";
import { Button } from "@/components/ui/button";
import { ServiceWithProvider } from "@shared/schema";
import { CheckCircle, Star, Shield, Search, Handshake, Percent, Clock, Users } from "lucide-react";

export default function Home() {
  const { data: featuredServices, isLoading } = useQuery<ServiceWithProvider[]>({
    queryKey: ["/api/services"],
  });

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Header />
      
      {/* Hero Section */}
      <section className="gradient-hero text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Get <span className="text-accent">profitable results</span> for your business in 24-48 hours
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90 max-w-3xl mx-auto">
            AI-powered content, proven marketing campaigns, professional designs, and tech setup. Fast delivery, guaranteed results.
          </p>
          
          {/* Hero Search */}
          <div className="max-w-2xl mx-auto mb-8">
            <SearchBar />
          </div>

          {/* Trust Indicators */}
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm opacity-80">
            <div className="flex items-center">
              <CheckCircle className="mr-2 w-5 h-5" />
              <span>10,000+ successful projects</span>
            </div>
            <div className="flex items-center">
              <Star className="mr-2 w-5 h-5" />
              <span>24-48 hour delivery</span>
            </div>
            <div className="flex items-center">
              <Shield className="mr-2 w-5 h-5" />
              <span>Results guaranteed or refund</span>
            </div>
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">High-ROI Digital Services</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Services designed to generate immediate results and increase your revenue within days
          </p>
          <CategoryGrid />
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Profit-Generating Services</h2>
            <Link href="/services" className="text-primary hover:text-blue-700 font-medium">
              View All →
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Array.from({ length: 4 }, (_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 rounded-lg h-80"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredServices?.slice(0, 4).map((service) => (
                <ServiceCard key={service.id} service={service} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-4">Get Results in 3 Simple Steps</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Order proven services that generate immediate results for your business growth.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">1. Choose Your Service</h3>
              <p className="text-gray-600">
                Select from high-ROI services designed to boost your business. All with proven track records and fast delivery.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-secondary rounded-full flex items-center justify-center mx-auto mb-4">
                <Handshake className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">2. Place Your Order</h3>
              <p className="text-gray-600">
                Secure payment and provide your requirements. Our experts start working immediately on your project.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">3. See Immediate Results</h3>
              <p className="text-gray-600">
                Get your completed work in 24-48 hours. Track your ROI and watch your business grow instantly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Seller CTA */}
      <section className="py-16 gradient-cta text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to make serious money?
          </h2>
          <p className="text-xl mb-8 opacity-90 max-w-2xl mx-auto">
            Sell high-value digital services with proven demand. Earn $50-$500 per order with our tested service templates.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link href="/create-service">
              <Button className="bg-white text-secondary px-8 py-3 rounded-lg font-semibold hover:bg-gray-100">
                Become a Seller
              </Button>
            </Link>
            <Button variant="outline" className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-secondary">
              Learn More
            </Button>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 pt-12 border-t border-green-500 border-opacity-30">
            <div className="flex items-center justify-center">
              <Percent className="text-2xl mr-3" />
              <span className="text-lg">Earn $50-500 per order</span>
            </div>
            <div className="flex items-center justify-center">
              <Clock className="text-2xl mr-3" />
              <span className="text-lg">Daily payouts</span>
            </div>
            <div className="flex items-center justify-center">
              <Users className="text-2xl mr-3" />
              <span className="text-lg">Proven service templates</span>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
