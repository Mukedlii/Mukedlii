import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ServiceWithProvider, Review } from "@shared/schema";
import { Star, Clock, CheckCircle, MessageCircle } from "lucide-react";
import { useAuth } from "@/lib/auth";

export default function ServiceDetail() {
  const [location] = useLocation();
  const { user } = useAuth();
  const serviceId = location.split('/')[2];

  const { data: service, isLoading } = useQuery<ServiceWithProvider>({
    queryKey: [`/api/services/${serviceId}`],
  });

  const { data: reviews } = useQuery<Review[]>({
    queryKey: [`/api/services/${serviceId}/reviews`],
    enabled: !!serviceId,
  });

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(0)}`;
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < rating ? "text-yellow-400 fill-current" : "text-gray-300"
        }`}
      />
    ));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 rounded-lg h-96 mb-8"></div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <div className="bg-gray-200 rounded-lg h-64"></div>
              </div>
              <div className="bg-gray-200 rounded-lg h-96"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Service not found</h1>
          <Link href="/services">
            <Button>Browse Services</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Service Image */}
        <div className="mb-8">
          <img
            src={service.image || "/placeholder-service.jpg"}
            alt={service.title}
            className="w-full h-96 object-cover rounded-lg"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <Badge variant="secondary" className="mb-2">
                {service.category.name}
              </Badge>
              <h1 className="text-3xl font-bold text-gray-900 mb-4">
                {service.title}
              </h1>
              
              {/* Provider Info */}
              <div className="flex items-center mb-6">
                <Avatar className="w-12 h-12 mr-4">
                  <AvatarImage src={service.provider.profileImage || ""} alt={service.provider.fullName} />
                  <AvatarFallback>{service.provider.fullName?.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-gray-900">{service.provider.fullName}</p>
                  <div className="flex items-center">
                    <div className="flex mr-2">
                      {renderStars(service.provider.rating || 0)}
                    </div>
                    <span className="text-gray-600 text-sm">
                      {service.provider.rating?.toFixed(1)} ({service.provider.reviewCount} reviews)
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            <Card className="mb-6">
              <CardContent className="p-6">
                <h2 className="text-xl font-semibold mb-4">About This Service</h2>
                <p className="text-gray-700 whitespace-pre-line">{service.description}</p>
              </CardContent>
            </Card>

            {/* Features */}
            {service.features && service.features.length > 0 && (
              <Card className="mb-6">
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">What You Get</h2>
                  <ul className="space-y-2">
                    {service.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}

            {/* Reviews */}
            {reviews && reviews.length > 0 && (
              <Card>
                <CardContent className="p-6">
                  <h2 className="text-xl font-semibold mb-4">Reviews</h2>
                  <div className="space-y-4">
                    {reviews.map((review) => (
                      <div key={review.id} className="border-b border-gray-200 pb-4 last:border-b-0">
                        <div className="flex items-center mb-2">
                          <div className="flex mr-2">
                            {renderStars(review.rating)}
                          </div>
                          <span className="text-sm text-gray-600">
                            {new Date(review.createdAt || '').toLocaleDateString()}
                          </span>
                        </div>
                        {review.comment && (
                          <p className="text-gray-700">{review.comment}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div>
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <span className="text-3xl font-bold text-gray-900">
                    {formatPrice(service.price)}
                  </span>
                  <p className="text-gray-600">Starting price</p>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Delivery</span>
                    </div>
                    <span className="text-sm font-medium">
                      {service.deliveryTime} day{service.deliveryTime !== 1 ? 's' : ''}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-600">Rating</span>
                    </div>
                    <span className="text-sm font-medium">
                      {service.rating}/5 ({service.reviewCount} reviews)
                    </span>
                  </div>
                </div>

                <Separator className="mb-6" />

                <div className="space-y-3">
                  {user ? (
                    <>
                      <Link href={`/checkout/${service.id}`}>
                        <Button className="w-full" size="lg">
                          Continue ({formatPrice(service.price)})
                        </Button>
                      </Link>
                      <Button variant="outline" className="w-full" size="lg">
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Contact Seller
                      </Button>
                    </>
                  ) : (
                    <Link href="/auth">
                      <Button className="w-full" size="lg">
                        Sign In to Continue
                      </Button>
                    </Link>
                  )}
                </div>

                <div className="mt-6 text-center">
                  <p className="text-xs text-gray-500">
                    Secure payment with money-back guarantee
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
