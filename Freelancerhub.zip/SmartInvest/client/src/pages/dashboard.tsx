import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";
import { OrderWithDetails, ServiceWithProvider } from "@shared/schema";
import { Plus, DollarSign, ShoppingCart, Star, User, Mail, Calendar, MapPin, Crown } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [location] = useLocation();
  
  // Check for tab parameter in URL
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const activeTab = urlParams.get('tab') || 'orders';

  const { data: orders, isLoading: ordersLoading } = useQuery<OrderWithDetails[]>({
    queryKey: ["/api/orders", { userId: user?.id }],
    enabled: !!user,
  });

  const { data: services, isLoading: servicesLoading } = useQuery<ServiceWithProvider[]>({
    queryKey: [`/api/users/${user?.id}/services`],
    enabled: !!user?.isProvider,
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Please sign in to view your dashboard</h1>
          <Link href="/auth">
            <Button>Sign In</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  const myOrders = orders?.filter(order => order.clientId === user.id) || [];
  const myProviderOrders = orders?.filter(order => order.providerId === user.id) || [];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-100 text-yellow-800";
      case "in_progress": return "bg-blue-100 text-blue-800";
      case "completed": return "bg-green-100 text-green-800";
      case "cancelled": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {user.fullName}!
          </h1>
          <p className="text-gray-600">Manage your orders, services, and account</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <ShoppingCart className="h-8 w-8 text-blue-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Active Orders</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {myOrders.filter(o => o.status === "pending" || o.status === "in_progress").length}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center">
                <DollarSign className="h-8 w-8 text-green-600" />
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Total Spent</p>
                  <p className="text-2xl font-bold text-gray-900">
                    ${((myOrders.reduce((sum, order) => sum + order.totalAmount, 0)) / 100).toFixed(0)}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {user.isProvider && (
            <>
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Star className="h-8 w-8 text-yellow-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">My Services</p>
                      <p className="text-2xl font-bold text-gray-900">{services?.length || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <DollarSign className="h-8 w-8 text-purple-600" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Earnings</p>
                    <p className="text-2xl font-bold text-gray-900">
                      ${((myProviderOrders.reduce((sum, order) => sum + order.totalAmount, 0)) / 100).toFixed(0)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
            </>
          )}
        </div>

        <Tabs value={activeTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="orders">My Orders</TabsTrigger>
            {user.isProvider && (
              <>
                <TabsTrigger value="services">My Services</TabsTrigger>
                <TabsTrigger value="provider-orders">Incoming Orders</TabsTrigger>
              </>
            )}
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">My Orders</h2>
              <Link href="/services">
                <Button>Browse Services</Button>
              </Link>
            </div>

            {ordersLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }, (_, i) => (
                  <div key={i} className="animate-pulse">
                    <Card>
                      <CardContent className="p-6">
                        <div className="bg-gray-200 h-20 rounded"></div>
                      </CardContent>
                    </Card>
                  </div>
                ))}
              </div>
            ) : myOrders.length > 0 ? (
              <div className="space-y-4">
                {myOrders.map((order) => (
                  <Card key={order.id}>
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <img
                            src={order.service.image || "/placeholder-service.jpg"}
                            alt={order.service.title}
                            className="w-16 h-16 object-cover rounded"
                          />
                          <div>
                            <h3 className="font-semibold text-gray-900">{order.service.title}</h3>
                            <p className="text-sm text-gray-600">by {order.provider.fullName}</p>
                            <p className="text-sm text-gray-500">
                              Order #{order.id} • {new Date(order.createdAt || '').toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className={getStatusColor(order.status)}>
                            {order.status.replace('_', ' ')}
                          </Badge>
                          <p className="text-lg font-semibold mt-2">
                            ${(order.totalAmount / 100).toFixed(0)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-6 text-center">
                  <p className="text-gray-600 mb-4">You haven't placed any orders yet.</p>
                  <Link href="/services">
                    <Button>Browse Services</Button>
                  </Link>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {user.isProvider && (
            <>
              <TabsContent value="services" className="space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-semibold">My Services</h2>
                  <Link href="/create-service">
                    <Button>
                      <Plus className="w-4 h-4 mr-2" />
                      Create Service
                    </Button>
                  </Link>
                </div>

                {servicesLoading ? (
                  <div className="space-y-4">
                    {Array.from({ length: 3 }, (_, i) => (
                      <div key={i} className="animate-pulse">
                        <Card>
                          <CardContent className="p-6">
                            <div className="bg-gray-200 h-20 rounded"></div>
                          </CardContent>
                        </Card>
                      </div>
                    ))}
                  </div>
                ) : services && services.length > 0 ? (
                  <div className="space-y-4">
                    {services.map((service) => (
                      <Card key={service.id}>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-4">
                              <img
                                src={service.image || "/placeholder-service.jpg"}
                                alt={service.title}
                                className="w-16 h-16 object-cover rounded"
                              />
                              <div>
                                <h3 className="font-semibold text-gray-900">{service.title}</h3>
                                <p className="text-sm text-gray-600">{service.category.name}</p>
                                <p className="text-sm text-gray-500">
                                  {service.reviewCount} reviews • {service.rating}/5 rating
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge variant={service.isActive ? "default" : "secondary"}>
                                {service.isActive ? "Active" : "Inactive"}
                              </Badge>
                              <p className="text-lg font-semibold mt-2">
                                ${(service.price / 100).toFixed(0)}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-6 text-center">
                      <p className="text-gray-600 mb-4">You haven't created any services yet.</p>
                      <Link href="/create-service">
                        <Button>
                          <Plus className="w-4 h-4 mr-2" />
                          Create Your First Service
                        </Button>
                      </Link>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="provider-orders" className="space-y-6">
                <h2 className="text-xl font-semibold">Incoming Orders</h2>

                {ordersLoading ? (
                  <div className="space-y-4">
                    {Array.from({ length: 3 }, (_, i) => (
                      <div key={i} className="animate-pulse">
                        <Card>
                          <CardContent className="p-6">
                            <div className="bg-gray-200 h-20 rounded"></div>
                          </CardContent>
                        </Card>
                      </div>
                    ))}
                  </div>
                ) : myProviderOrders.length > 0 ? (
                  <div className="space-y-4">
                    {myProviderOrders.map((order) => (
                      <Card key={order.id}>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-4">
                              <img
                                src={order.service.image || "/placeholder-service.jpg"}
                                alt={order.service.title}
                                className="w-16 h-16 object-cover rounded"
                              />
                              <div>
                                <h3 className="font-semibold text-gray-900">{order.service.title}</h3>
                                <p className="text-sm text-gray-600">from {order.client.fullName}</p>
                                <p className="text-sm text-gray-500">
                                  Order #{order.id} • {new Date(order.createdAt || '').toLocaleDateString()}
                                </p>
                                {order.requirements && (
                                  <p className="text-sm text-gray-700 mt-2">
                                    <strong>Requirements:</strong> {order.requirements}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge className={getStatusColor(order.status)}>
                                {order.status.replace('_', ' ')}
                              </Badge>
                              <p className="text-lg font-semibold mt-2">
                                ${(order.totalAmount / 100).toFixed(0)}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card>
                    <CardContent className="p-6 text-center">
                      <p className="text-gray-600">No incoming orders yet.</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            </>
          )}

          <TabsContent value="profile" className="space-y-6">
            <div className="max-w-2xl">
              <h2 className="text-xl font-semibold mb-6">Profile Settings</h2>
              
              {/* Profile Header */}
              <Card className="mb-6">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-6">
                    <Avatar className="w-20 h-20">
                      <AvatarImage src={user.profileImage} />
                      <AvatarFallback className="text-xl">
                        {user.fullName?.charAt(0) || user.username?.charAt(0) || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="text-xl font-semibold">{user.fullName}</h3>
                        {user.isPremium && (
                          <Badge className="bg-yellow-100 text-yellow-800">
                            <Crown className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                        {user.isProvider && (
                          <Badge variant="secondary">Provider</Badge>
                        )}
                      </div>
                      <p className="text-gray-600">@{user.username}</p>
                      {user.isProvider && (
                        <div className="flex items-center space-x-4 mt-2">
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 mr-1" />
                            <span className="text-sm">{user.rating?.toFixed(1) || '0.0'}</span>
                          </div>
                          <span className="text-sm text-gray-500">
                            {user.reviewCount || 0} reviews
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Account Information */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Account Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="fullName">Full Name</Label>
                      <Input 
                        id="fullName" 
                        value={user.fullName} 
                        disabled 
                        className="bg-gray-50"
                      />
                    </div>
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input 
                        id="username" 
                        value={user.username} 
                        disabled 
                        className="bg-gray-50"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <div className="flex items-center">
                      <Mail className="w-4 h-4 mr-2 text-gray-400" />
                      <Input 
                        id="email" 
                        value={user.email} 
                        disabled 
                        className="bg-gray-50"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea 
                      id="bio" 
                      value={user.bio || 'No bio added yet'} 
                      disabled 
                      className="bg-gray-50"
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="joinDate">Member Since</Label>
                    <div className="flex items-center">
                      <Calendar className="w-4 h-4 mr-2 text-gray-400" />
                      <Input 
                        id="joinDate" 
                        value={new Date(user.createdAt || '').toLocaleDateString()} 
                        disabled 
                        className="bg-gray-50"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Provider Stats */}
              {user.isProvider && (
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Star className="w-5 h-5 mr-2" />
                      Provider Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">
                          {services?.length || 0}
                        </div>
                        <div className="text-sm text-gray-600">Services</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          {user.reviewCount || 0}
                        </div>
                        <div className="text-sm text-gray-600">Reviews</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-yellow-600">
                          {user.rating?.toFixed(1) || '0.0'}
                        </div>
                        <div className="text-sm text-gray-600">Rating</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">
                          ${((user.totalEarnings || 0) / 100).toFixed(0)}
                        </div>
                        <div className="text-sm text-gray-600">Earnings</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Premium Section */}
              {user.isProvider && !user.isPremium && (
                <Card className="border-yellow-200 bg-yellow-50">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-lg font-semibold text-yellow-800 mb-2">
                          Upgrade to Premium
                        </h3>
                        <p className="text-yellow-700">
                          Get featured listings, advanced analytics, and priority support
                        </p>
                      </div>
                      <Link href="/subscribe">
                        <Button className="bg-yellow-600 hover:bg-yellow-700">
                          <Crown className="w-4 h-4 mr-2" />
                          Go Premium
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Actions */}
              <div className="flex space-x-4">
                <Button variant="outline" className="flex-1">
                  Edit Profile
                </Button>
                <Button variant="outline" className="flex-1">
                  Account Settings
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  );
}
