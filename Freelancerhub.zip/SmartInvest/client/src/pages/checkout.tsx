import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth";
import { ServiceWithProvider } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ service, requirements }: { service: ServiceWithProvider; requirements: string }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [isProcessing, setIsProcessing] = useState(false);

  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order placed successfully!",
        description: "You will receive an email confirmation shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      navigate("/dashboard");
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);

    if (!stripe || !elements || !user) {
      setIsProcessing(false);
      return;
    }

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard`,
        },
        redirect: "if_required",
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      } else {
        // Create order in database
        await createOrderMutation.mutateAsync({
          serviceId: service.id,
          clientId: user.id,
          providerId: service.providerId,
          totalAmount: service.price,
          requirements,
          status: "pending",
        });
      }
    } catch (error: any) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        className="w-full" 
        size="lg" 
        disabled={!stripe || isProcessing}
      >
        {isProcessing ? "Processing..." : `Pay $${(service.price / 100).toFixed(0)}`}
      </Button>
    </form>
  );
};

export default function Checkout() {
  const [match, params] = useRoute("/checkout/:serviceId");
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [requirements, setRequirements] = useState("");
  const [clientSecret, setClientSecret] = useState("");

  const serviceId = params?.serviceId;

  const { data: service, isLoading } = useQuery<ServiceWithProvider>({
    queryKey: [`/api/services/${serviceId}`],
    enabled: !!serviceId,
  });

  useEffect(() => {
    if (!user) {
      navigate("/auth");
      return;
    }

    if (service) {
      // Create PaymentIntent when service is loaded
      apiRequest("POST", "/api/create-payment-intent", { 
        amount: service.price 
      })
        .then((res) => res.json())
        .then((data) => {
          setClientSecret(data.clientSecret);
        })
        .catch((error) => {
          console.error("Error creating payment intent:", error);
        });
    }
  }, [service, user, navigate]);

  if (!user) {
    return null; // Redirecting to auth
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 rounded-lg h-96"></div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Service not found</h1>
          <Button onClick={() => navigate("/services")}>
            Browse Services
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  if (!clientSecret) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="max-w-4xl mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-96">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20 md:pb-0">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Checkout</h1>
          <p className="text-gray-600">Review your order and complete your purchase</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-4">
                  <img
                    src={service.image || "/placeholder-service.jpg"}
                    alt={service.title}
                    className="w-20 h-20 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{service.title}</h3>
                    <p className="text-sm text-gray-600">by {service.provider.fullName}</p>
                    <p className="text-sm text-gray-600">
                      Delivery: {service.deliveryTime} day{service.deliveryTime !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-lg">${(service.price / 100).toFixed(0)}</p>
                  </div>
                </div>

                <Separator />

                <div>
                  <Label htmlFor="requirements" className="text-sm font-medium">
                    Project Requirements (Optional)
                  </Label>
                  <Textarea
                    id="requirements"
                    placeholder="Describe your specific requirements, preferences, or any additional details..."
                    value={requirements}
                    onChange={(e) => setRequirements(e.target.value)}
                    className="mt-2"
                    rows={4}
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${(service.price / 100).toFixed(0)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service fee (5%)</span>
                    <span>${((service.price * 0.05) / 100).toFixed(0)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>${((service.price * 1.05) / 100).toFixed(0)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Payment Form */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Payment Information</CardTitle>
              </CardHeader>
              <CardContent>
                <Elements stripe={stripePromise} options={{ clientSecret }}>
                  <CheckoutForm service={service} requirements={requirements} />
                </Elements>
                
                <div className="mt-6 text-center">
                  <p className="text-xs text-gray-500">
                    🔒 Your payment information is secure and encrypted
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Protected by our money-back guarantee
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
