import { useState } from 'react';
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/lib/auth';
import { Check, Star, Zap, Crown } from 'lucide-react';
import Header from '@/components/header';
import Footer from '@/components/footer';
import { apiRequest } from '@/lib/queryClient';

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = ({ planType, planDetails }: { planType: string; planDetails: any }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;

    setIsLoading(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/dashboard?subscription=success`,
        },
      });

      if (error) {
        toast({
          title: "Payment Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          {planDetails.icon}
          {planDetails.name}
        </CardTitle>
        <CardDescription>
          Complete your {planDetails.name} subscription
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="text-center py-4">
            <div className="text-3xl font-bold">${planDetails.price}/month</div>
            <div className="text-gray-600">Billed monthly</div>
          </div>
          
          <PaymentElement />
          
          <Button
            type="submit"
            disabled={!stripe || isLoading}
            className="w-full"
            size="lg"
          >
            {isLoading ? 'Processing...' : `Subscribe for $${planDetails.price}/month`}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  const { user } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [clientSecret, setClientSecret] = useState<string>('');
  const { toast } = useToast();

  const plans = [
    {
      id: 'basic',
      name: 'Basic Premium',
      price: 29,
      icon: <Star className="w-5 h-5 text-yellow-500" />,
      features: [
        'Kiemelt szolgáltatás megjelenítés',
        'Prioritás a keresési eredményekben',
        'Basic analytics dashboard',
        'Email támogatás',
        'Korlátlan szolgáltatás publikálás'
      ],
      popular: false
    },
    {
      id: 'professional',
      name: 'Professional',
      price: 59,
      icon: <Zap className="w-5 h-5 text-blue-500" />,
      features: [
        'Minden Basic Premium funkció',
        'Részletes analytics és bevétel tracking',
        'Featured badge a profiljában',
        'Prioritás chat támogatás',
        'Custom portfolio showcase',
        'Automated marketing tools'
      ],
      popular: true
    },
    {
      id: 'business',
      name: 'Business',
      price: 99,
      icon: <Crown className="w-5 h-5 text-purple-500" />,
      features: [
        'Minden Professional funkció',
        'Személyes account manager',
        'White-label branding opciók',
        'API hozzáférés',
        'Bulk service management',
        'Advanced marketplace insights',
        '24/7 telefon támogatás'
      ],
      popular: false
    }
  ];

  const handlePlanSelect = async (planType: string) => {
    if (!user) {
      toast({
        title: "Bejelentkezés szükséges",
        description: "Kérjük jelentkezzen be az előfizetéshez",
        variant: "destructive",
      });
      return;
    }

    try {
      const response = await apiRequest('POST', '/api/create-subscription', { planType });
      const data = await response.json();
      
      setClientSecret(data.clientSecret);
      setSelectedPlan(planType);
    } catch (error) {
      toast({
        title: "Hiba",
        description: "Nem sikerült létrehozni az előfizetést",
        variant: "destructive",
      });
    }
  };

  if (selectedPlan && clientSecret) {
    const planDetails = plans.find(p => p.id === selectedPlan)!;
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="py-12">
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <SubscribeForm planType={selectedPlan} planDetails={planDetails} />
          </Elements>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Premium Provider Előfizetések
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Növelje bevételeit és kiemelkedjen a versenytársai közül prémium funkcióinkkal
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan) => (
              <Card 
                key={plan.id} 
                className={`relative ${plan.popular ? 'border-primary border-2' : ''}`}
              >
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    Legnépszerűbb
                  </Badge>
                )}
                
                <CardHeader className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    {plan.icon}
                    <CardTitle className="text-xl">{plan.name}</CardTitle>
                  </div>
                  <div className="text-4xl font-bold">${plan.price}</div>
                  <CardDescription>/hó</CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <ul className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <Check className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button
                    onClick={() => handlePlanSelect(plan.id)}
                    className="w-full"
                    variant={plan.popular ? 'default' : 'outline'}
                    size="lg"
                  >
                    Előfizetés Indítása
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="bg-white rounded-lg p-8 max-w-3xl mx-auto">
              <h3 className="text-2xl font-bold mb-4">Miért válassza a Premium előfizetést?</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-primary">3x</div>
                  <div className="text-gray-600">Több megrendelés</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">50%</div>
                  <div className="text-gray-600">Magasabb bevétel</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-primary">24h</div>
                  <div className="text-gray-600">Gyorsabb válaszidő</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}