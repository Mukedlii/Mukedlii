import { useState, useEffect } from 'react';

interface MobileAppState {
  isStandalone: boolean;
  isIOS: boolean;
  isAndroid: boolean;
  canInstall: boolean;
  orientation: 'portrait' | 'landscape';
}

export function useMobileApp() {
  const [appState, setAppState] = useState<MobileAppState>({
    isStandalone: false,
    isIOS: false,
    isAndroid: false,
    canInstall: false,
    orientation: 'portrait'
  });

  useEffect(() => {
    const checkStandalone = () => {
      const isStandaloneMode = 
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone ||
        document.referrer.includes('android-app://');
      
      return isStandaloneMode;
    };

    const checkPlatform = () => {
      const userAgent = window.navigator.userAgent;
      const isIOS = /iPad|iPhone|iPod/.test(userAgent);
      const isAndroid = /Android/.test(userAgent);
      
      return { isIOS, isAndroid };
    };

    const checkOrientation = () => {
      return window.innerHeight > window.innerWidth ? 'portrait' : 'landscape';
    };

    const updateAppState = () => {
      const { isIOS, isAndroid } = checkPlatform();
      
      setAppState({
        isStandalone: checkStandalone(),
        isIOS,
        isAndroid,
        canInstall: !checkStandalone() && (isIOS || isAndroid),
        orientation: checkOrientation()
      });
    };

    // Initial check
    updateAppState();

    // Listen for orientation changes
    const handleOrientationChange = () => {
      setTimeout(updateAppState, 100); // Delay to ensure dimensions are updated
    };

    // Listen for app install events
    const handleAppInstalled = () => {
      updateAppState();
    };

    window.addEventListener('orientationchange', handleOrientationChange);
    window.addEventListener('resize', handleOrientationChange);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('orientationchange', handleOrientationChange);
      window.removeEventListener('resize', handleOrientationChange);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const showInstallPrompt = () => {
    // This would trigger the install prompt if available
    const event = (window as any).deferredPrompt;
    if (event) {
      event.prompt();
    }
  };

  const shareApp = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'FreelancerHub',
          text: 'Check out FreelancerHub - the modern freelance marketplace!',
          url: window.location.origin,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    }
  };

  const addToHomeScreen = () => {
    // Instructions for manual installation
    if (appState.isIOS) {
      alert('To install this app, tap the Share button and then "Add to Home Screen"');
    } else if (appState.isAndroid) {
      alert('To install this app, tap the menu button and then "Add to Home Screen" or "Install App"');
    }
  };

  return {
    ...appState,
    showInstallPrompt,
    shareApp,
    addToHomeScreen
  };
}