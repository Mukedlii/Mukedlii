# FreelancerHub - Freelance Services Marketplace

## Overview

FreelancerHub is a modern freelance services marketplace built with a full-stack TypeScript architecture. The platform connects service providers with clients, offering features like service listings, order management, payment processing through Stripe, and user authentication. The application follows a clean architecture pattern with a React frontend, Express backend, and PostgreSQL database managed through Drizzle ORM.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Radix UI with Tailwind CSS for styling
- **Build Tool**: Vite for development and production builds
- **Component Library**: shadcn/ui components for consistent design
- **Mobile App**: Progressive Web App (PWA) with offline capabilities and native-like experience

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API architecture
- **Development**: TSX for TypeScript execution in development
- **Production**: esbuild for optimized bundling

### Database Architecture
- **Database**: PostgreSQL 16
- **ORM**: Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless driver
- **Migrations**: Drizzle Kit for schema management

## Key Components

### Authentication System
- Custom authentication implementation without sessions
- LocalStorage-based user persistence
- Password-based authentication (note: passwords are stored in plain text - not production ready)
- User role management (clients vs providers)

### Service Management
- Service creation and listing functionality
- Category-based organization
- Image upload support
- Price management in cents for precision
- Rating and review systems

### Order Processing
- Complete order lifecycle management
- Status tracking (pending, in_progress, completed, cancelled)
- Client requirements handling
- Provider-client communication support

### Payment Integration
- Stripe integration for secure payment processing
- Environment-based configuration
- Payment intent creation and confirmation
- Order completion upon successful payment

### Data Models
Key entities include:
- **Users**: Handles both clients and service providers
- **Categories**: Service categorization system
- **Services**: Core service offerings with pricing and features
- **Orders**: Transaction management between clients and providers
- **Reviews**: Rating and feedback system
- **Messages**: Communication between users

## Data Flow

1. **User Registration/Login**: Users authenticate and their data is stored in localStorage
2. **Service Discovery**: Clients browse services by category or search terms
3. **Service Selection**: Clients view service details and provider information
4. **Order Creation**: Clients initiate orders with specific requirements
5. **Payment Processing**: Stripe handles secure payment transactions
6. **Order Management**: Both parties track order progress through the dashboard
7. **Communication**: Users can exchange messages regarding orders
8. **Review System**: Clients can rate and review completed services

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Database connectivity
- **drizzle-orm**: Type-safe database operations
- **stripe**: Payment processing
- **@tanstack/react-query**: Server state management
- **wouter**: Client-side routing
- **react-hook-form**: Form handling with validation

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Icon library
- **class-variance-authority**: Component variant management

### Development Dependencies
- **vite**: Build tool and dev server
- **tsx**: TypeScript execution for development
- **esbuild**: Production bundling
- **drizzle-kit**: Database schema management

## Deployment Strategy

### Development Environment
- **Runtime**: Node.js 20 with PostgreSQL 16 module
- **Dev Server**: Vite dev server with HMR on port 5000
- **Database**: Automatic PostgreSQL provisioning
- **Environment**: Replit-optimized with cartographer plugin

### Production Deployment
- **Platform**: Replit autoscale deployment
- **Build Process**: Two-stage build (Vite for frontend, esbuild for backend)
- **Static Assets**: Frontend builds to `dist/public`
- **Server**: Express serves both API and static files
- **Environment Variables**: Stripe keys and database URL required

### Configuration Requirements
- `DATABASE_URL`: PostgreSQL connection string
- `STRIPE_SECRET_KEY`: Server-side Stripe configuration
- `VITE_STRIPE_PUBLIC_KEY`: Client-side Stripe configuration

## Changelog

Changelog:
- June 24, 2025. Initial setup
- June 24, 2025. Added Progressive Web App (PWA) functionality with mobile optimization
- June 24, 2025. Fixed Browse services functionality - SelectItem value prop error resolved
- June 24, 2025. Completed Stripe integration testing - fully functional payment system
- June 24, 2025. Created comprehensive development roadmap with 18 feature suggestions
- June 24, 2025. Implemented complete rating and review system with star ratings, detailed reviews, helpful votes, and provider rating updates
- June 24, 2025. Updated branding from SkillBridge to FreelancerHub to match domain name
- June 24, 2025. Implemented monetization strategy with 10% platform commission system and premium features
- June 24, 2025. Added Testing & QA service category for beta testers and QA professionals
- June 24, 2025. Enhanced mobile app version with PWA improvements, mobile-optimized components, and native app shell
- June 24, 2025. Fixed profile navigation and added complete profile page with user stats and premium upgrade prompts
- June 24, 2025. Optimized app performance with lazy loading, code splitting, and improved service worker caching
- June 24, 2025. Fixed deployment issues and added traffic monitoring to track real visitors vs development testing

## User Preferences

Preferred communication style: Simple, everyday language.
Language: Hungarian (Magyar)